A=input()
print(type(A))
