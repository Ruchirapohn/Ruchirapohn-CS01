A=input("Ruchirapohn")
print(A)