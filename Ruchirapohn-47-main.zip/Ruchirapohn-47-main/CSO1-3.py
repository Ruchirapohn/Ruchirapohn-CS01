A=input("16/04/2549")
print(A)