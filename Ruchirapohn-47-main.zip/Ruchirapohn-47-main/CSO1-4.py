A=100
B=5
C=A+B
C=A-B
C=A*B
C=A/B
print(C)