A= float(input())
if(A>5):
  print("yes")