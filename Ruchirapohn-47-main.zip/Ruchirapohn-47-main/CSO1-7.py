A=float(input("์Number:"))
if(A <=10):
    print("ไม่ผ่าน")
elif(A <=20):
    print("ปรับปรุง")
elif(A <=30):
    print("ดีมาก")
else:
    print("error")