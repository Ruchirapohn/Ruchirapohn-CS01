A = int(input())
B = int(input())
C = A + B
print(C)